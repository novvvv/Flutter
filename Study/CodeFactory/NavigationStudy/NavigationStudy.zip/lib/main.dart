import 'package:flutter/material.dart';
import 'package:helloworld/screen/home_screen.dart';
import 'package:helloworld/screen/route_one_screen.dart';
import 'package:helloworld/screen/route_two_screen.dart';
import 'package:helloworld/screen/route_three_screen.dart';

void main() {
  runApp(
    MaterialApp(
      // home: HomeScreen(),
      // initialRoute : 처음 app 실행 시 출력되는 화면
      initialRoute: '/',
      // named Route 방식
      // www.google.com -> www.google.com/
      routes: {
        // builder method
        '/': (context) => HomeScreen(),
        '/one': (context) => RouteOneScreen(),
        '/two': (context) => RouteTwoScreen(),
        '/three': (context) => RouteThreeScreen(),
      },
    ),
  );
}
