import 'package:flutter/material.dart';
import 'package:helloworld/screen/route_one_screen.dart';
import 'package:helloworld/layout/main_layout.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // MainLayout Stateless Widget으로 appBar, Button 정보를 넘겨준다.
    // WillPopScope
    // Android OS에서 뒤로가기 버튼을 통한 강제 어플리케이션 종료를 방지할 수 있음.
    // 단, 프로그래머가 pop 버튼을 만들어 놓은 경우에는 막을 수 없다.
    return WillPopScope(
      onWillPop: () async {
        // true - pop 가능
        // false - pop 불가능
        final canPop = Navigator.of(context).canPop();
        return canPop;
      },
      child: MainLayout(
        title: 'Home Screen',
        children: [
          // canPop Method
          // Navigator Stack Route 존재 여부를 Bool로 Return한다.
          ElevatedButton(
            onPressed: () {
              print(Navigator.of(context).canPop());
            },
            child: Text('Can Pop'),
          ),
          // maybePop Method
          // Navigation Stack에 Route가 존재하지 않는 상황에서 Pop을 했을 때
          // 생기는 에러를 방지할 수 있다.
          // maybePop은 canPop이 True일 경우에만 Pop할 수 있다.
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).maybePop();
            },
            child: Text('Maybe Pop'),
          ),
          ElevatedButton(
            onPressed: () async {
              final result = await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (BuildContext context) => RouteOneScreen(
                    number: 123,
                  ),
                ),
              );
              print(result);
            },
            child: Text('Push'),
          ),
        ],
      ),
    );
  }
}
