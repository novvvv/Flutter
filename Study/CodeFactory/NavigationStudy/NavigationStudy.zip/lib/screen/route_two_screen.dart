import 'package:flutter/material.dart';
import 'package:helloworld/layout/main_layout.dart';
import 'package:helloworld/main.dart';
import 'package:helloworld/screen/route_three_screen.dart';

class RouteTwoScreen extends StatelessWidget {
  const RouteTwoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // .of(context) Widget Tree에서 가장 가까운 ModalRoute를 가져온다.
    // ModalRoute -> Full Screen Widget을 의미
    // 단, 특정 상황에서는 ModalRoute를 가져올 수 없으니, !를 붙여서
    // null-Safety를 방지해 준다.
    final arguments = ModalRoute.of(context)!.settings.arguments;
    return MainLayout(
      title: "Route Two",
      children: [
        Text(
          'arguments: ${arguments}',
          textAlign: TextAlign.center,
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Pop'),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.of(context).pushNamed(
              '/three',
              arguments: 999,
            );
          },
          child: Text(
            'Push Named',
          ),
        ),
        ElevatedButton(
          onPressed: () {
            // 기존방식
            // [HomeScreen(), RouteOne(), RouteTwo(), RouteThree()]
            // pushReplacement & pushReplacementNamed
            // [HomeScreen(), RouteOne(), ("RouteTwo()" 제거), RouteThree()]
            Navigator.of(context).pushReplacementNamed(
              '/three',
            );
          },
          child: Text('Push Replacement'),
        ),
        // pushAndRemoveUntil -> Navigator stack에 저장된 모든 rotue를 삭제,
        // 단, parameter로 각각의 route를 받아서 false : 삭제, true : 살림 설정 가능.
        // 위와 같은 방식은 named Route 방식을 사용했을 경우에만 가능하다.
        // 아래처럼 route.settings.name을 homescreen으로 설정 시 homescreen을 제외한 나머지 route는 모두 삭제된다.
        ElevatedButton(
          onPressed: () {
            Navigator.of(context).pushNamedAndRemoveUntil(
              '/three',
              (route) => route.settings.name == '/',
            );
          },
          child: Text('Push And Remove Until'),
        ),
      ],
    );
  }
}

// Navigator.of(context).push() method
// push(Route<T> route) - route를 parameter에 직접 넣는 구조

// 'Named Route 방식'
// Navigator.of(context).pushNamed() method
// pushNamed(String routeName, ..) - String만 넣어 주어도 된다.
// main.dart file에서 설정한 routes의 Key들을 사용
// 단 pushNamed method를 사용하면 MaterialPageRoute를 사용하지 않기에,
// settings 값을 사용할 수가 없다
// 그렇기에 pushNamed에는 arguments값을 바로 parameter로 전달할 수 있는 기능을 가지고 있다.

// "Inflearn Study - 알고있으면 좋은 Push 메소드들"
// pushReplacement, pushReplacementNamed
// pushAndRemoveUntil, pushNamedAndRemoveUntil
