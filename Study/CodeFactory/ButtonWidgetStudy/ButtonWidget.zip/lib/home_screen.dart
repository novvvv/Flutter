import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Button'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () {},
              style: ButtonStyle(
                // ButtonStyle SClass를 직접 정의할 때는 MaerialStateProperty로 감싸 주어야 한다.
                // MaterialStateProperty.all => 모든 상태에 대하여 동일한 스타일을 적용.
                /* backgroundColor: MaterialStateProperty.all(
                  Colors.black,
                ), */
                backgroundColor: MaterialStateProperty.resolveWith(
                    (Set<MaterialState> states) {
                  if (states.contains(MaterialState.pressed)) {
                    return Colors.green;
                  }
                  return Colors.black;
                }),
                // button이 어떤 상태인지에 따라서 다른 색깔을 주입.
                // MaterialState -> 사용자 정의 enum class
                // MaterialState -> Flutter Flamework에서 기본적으로 사용되는 상태.
                // Button에만 국한되는 것은 아니다.
                // hovered - 호버링 상태 (마우스 커서를 올려놓은 상태) X
                // focused - 포커스 상태 (텍스트 필드) X
                // pressed - 눌렀을때 O
                // dragged - 드래그 됐을때 ..
                // selected - 선택됐을때 (체크박스, 라디오버튼) X
                // scrollUnder - 다른 컴포넌트 밑으로 스크롤링 됐을때 X
                // disabled - 비활성화 됐을때 .. onPressed가 Null인 경우 O
                // error - 에러상태 X
                //
                // MaterialStateProperty.resolveWith -> Set에 해당되는 상태가 들어온다.
                foregroundColor: MaterialStateProperty.resolveWith(
                  (Set<MaterialState> states) {
                    if (states.contains(MaterialState.pressed)) {
                      return Colors.white;
                    }
                    return Colors.red;
                  },
                ),
              ),
              child: Text(
                'ButtonStyle',
              ),
            ),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                // primary : main Color
                primary: Colors.blue,
                // onPrimary : 글자 및 애니메이션 색깔
                onPrimary: Colors.black,
                // shadowColor : 그림자 색깔
                shadowColor: Colors.green,
                // elevation : 3D 입체감 높이
                elevation: 10.0,
                textStyle: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 20.0,
                ),
                // padding : 글자 주변에 padding 추가.
                padding: EdgeInsets.all(32.0),
                side: BorderSide(
                  color: Colors.black,
                  width: 4.0,
                ),
              ),
              child: Text(
                'ElevatedButton',
              ),
            ),
            OutlinedButton(
              onPressed: () {},
              style: OutlinedButton.styleFrom(
                primary: Colors.green,
                backgroundColor: Colors.black,
              ),
              // OulinedButton의 주 효과는 글자, 애니메이션 효과이다.
              // 따라서 글자와 애니메이션 효과가 primary에 포함된다.
              // 그렇기에 별도의 onPrimary가 존재하지 않는다.
              // 배경색을 backgroundColor property로 바꿀수야 있겠다만, 그러면
              // 굳이 OutlinedButton을 쓰는 의미가 퇴색됨.
              child: Text(
                'OutlinedButton',
              ),
            ),
            TextButton(
              onPressed: () {},
              style: TextButton.styleFrom(
                primary: Colors.brown,
              ),
              child: Text(
                'TextButton',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// styleFrom() method는 내부적으로 ButtonStyle Class를 Return한다.
// 프로그래머가 ButtonStyle을 직접 정의 하는 것은 번거롭기에,
// ButtonStyle을 구현하기 쉽도록 내부적으로 미리 정의되어 있는 것이다.
